package com.example.budgetwise

data class CategoryTotalClass(val categoryId:Int,val title:String,val total:Double)
