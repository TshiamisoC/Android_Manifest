package com.example.budgetwise

data class CategoryClass(val id:Int,val title:String)
