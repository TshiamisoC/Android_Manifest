package com.example.budgetwise

data class UserClass(val userId:Int,val email:String,val password:String)
