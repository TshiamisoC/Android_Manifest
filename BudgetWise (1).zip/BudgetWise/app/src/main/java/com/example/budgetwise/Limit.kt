package com.example.budgetwise

data class Limit(val id:Int,val date:String,val amount:Double)
